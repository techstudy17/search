package com.ibs.util;

import com.ibs.dto.FlightSearchDTO;
import com.ibs.model.FlightScheduler;
/**
 * 
 * @author Sumya
 *
 */
public class FlightSearchUtility {

	/*public static FlightScheduler convertDTOToJaxBObject(FlightSearchDTO flightSchedulerDTO){
		FlightScheduler flightScheduler = new FlightScheduler();
		flightScheduler.setAvailability(flightSchedulerDTO.getAvailability());
		flightScheduler.setBookingclass(flightSchedulerDTO.getBookingclass());
		flightScheduler.setDeparturedate(flightSchedulerDTO.getDeparturedate());
		flightScheduler.setDestination(flightSchedulerDTO.getDestination());
		flightScheduler.setFlightnumber(flightSchedulerDTO.getFlightnumber());
		flightScheduler.setOrigin(flightSchedulerDTO.getOrigin());
		flightScheduler.setConnector(flightSchedulerDTO.getConnector());
		flightScheduler.setCareercode(flightSchedulerDTO.getCareercode());
		return flightScheduler;
	}*/
}
