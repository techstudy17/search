package com.ibs.dao;
/**
 * 
 * @author Sumya
 *
 */
import com.ibs.model.User;

public interface UserDao {
	Integer register(User user);
	}