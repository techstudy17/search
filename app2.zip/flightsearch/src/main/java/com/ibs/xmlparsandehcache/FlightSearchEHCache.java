package com.ibs.xmlparsandehcache;

import java.util.List;
import java.util.Map;

import com.ibs.model.FlightScheduler;
/**
 * 
 * @author Sumya
 *
 */
public interface FlightSearchEHCache {

public Map<String,FlightScheduler> FlightSearch();
}
