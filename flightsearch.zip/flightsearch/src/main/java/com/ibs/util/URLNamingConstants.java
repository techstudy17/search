package com.ibs.util;
/**
 * 
 * @author Sumya
 *
 */
public class URLNamingConstants {
	
	public static final String LOGIN_URL = "/";
	public static final String LOGIN_PROCESS = "/loginProcess";
	public static final String LOGOUT = "/logout";
	public static final String REGISTER_USER = "/registeruser";
	public static final String REGISTER_PROCESS = "/registerProcess";

}
