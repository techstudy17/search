package com.ibs.util;
/**
 * 
 * @author Sumya
 *
 */
public interface Constants {

	public String ERROR = "ERROR OCCURED";
	public String JMS_TEMPLATE_SEND_MESSAGE_ERROR = "Exception while configuring JMS Template";
	public String SUCCESSS = "success";
	
}
