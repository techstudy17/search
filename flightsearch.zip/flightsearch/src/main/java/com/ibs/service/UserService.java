package com.ibs.service;

import com.ibs.model.User;
/**
 * 
 * @author Sumya
 *
 */
public interface UserService {
	Integer register(User user);
}
